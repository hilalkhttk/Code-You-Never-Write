"""
Organize the Mess (The Files You Forgot)
------------------------------------------
Scans a folder for duplicate files, very large files, and groups files by
type. SAFE BY DESIGN: it never deletes or renames your originals. It only
COPIES files into a new "organized/" output folder, and it always shows
you the full plan before doing anything.

SAFETY ORDER (follow this — do not skip steps)
1. Make your own backup copy of the folder first, before running anything.
2. Run in DRY RUN mode (the default) to see the full plan:
       python organize_files.py /path/to/messy/folder
   Nothing is copied, moved, deleted, or renamed in dry-run mode.
3. Read the plan carefully.
4. Only once you approve, re-run WITH the --execute flag to actually copy
   files into the organized/ output folder:
       python organize_files.py /path/to/messy/folder --execute
5. Spot-check the organized/ folder. Your original folder is never touched.

PLAIN-ENGLISH LOGIC
- Duplicates: files with identical content (compared by hash, not just
  name) are grouped together. The first one found is treated as the
  "keeper"; the rest are flagged as duplicates.
- Large files: anything over LARGE_FILE_MB is flagged so you can decide
  whether to keep it.
- Grouping by type: every file is sorted into a folder named after its
  extension (e.g. .pdf, .png, .zip) inside organized/by-type/.
- Everything is a COPY. Your original folder and files are left exactly
  as they were, no matter what.
"""

import hashlib
import os
import shutil
import sys
from collections import defaultdict

LARGE_FILE_MB = 50  # files bigger than this are flagged as "large"


def hash_file(path, block_size=65536):
    h = hashlib.md5()
    with open(path, "rb") as f:
        while chunk := f.read(block_size):
            h.update(chunk)
    return h.hexdigest()


def scan_folder(root):
    files = []
    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            full_path = os.path.join(dirpath, name)
            try:
                size = os.path.getsize(full_path)
            except OSError:
                continue
            files.append({"path": full_path, "name": name, "size": size})
    return files


def build_plan(root, files):
    plan = {"duplicates": [], "large_files": [], "by_type": defaultdict(list)}

    hashes = {}
    for f in files:
        try:
            file_hash = hash_file(f["path"])
        except OSError:
            continue
        f["hash"] = file_hash
        if file_hash in hashes:
            plan["duplicates"].append({"keeper": hashes[file_hash], "duplicate": f["path"]})
        else:
            hashes[file_hash] = f["path"]

        if f["size"] > LARGE_FILE_MB * 1024 * 1024:
            plan["large_files"].append((f["path"], f["size"] / (1024 * 1024)))

        ext = os.path.splitext(f["name"])[1].lower() or "no_extension"
        plan["by_type"][ext].append(f["path"])

    return plan


def print_plan(plan):
    print("=== DRY RUN PLAN (nothing has been touched) ===\n")

    print(f"Duplicate files found: {len(plan['duplicates'])}")
    for d in plan["duplicates"]:
        print(f"  - DUPLICATE of '{d['keeper']}':\n      {d['duplicate']}")

    print(f"\nLarge files (> {LARGE_FILE_MB} MB): {len(plan['large_files'])}")
    for path, size_mb in plan["large_files"]:
        print(f"  - {path}  ({size_mb:.1f} MB)")

    print(f"\nFile types found: {len(plan['by_type'])}")
    for ext, paths in plan["by_type"].items():
        print(f"  - {ext}: {len(paths)} file(s)")

    print("\nPLANNED ACTIONS if you run with --execute:")
    print("  - Every file will be COPIED (not moved) into organized/by-type/<extension>/")
    print("  - Duplicate files will ALSO be copied into organized/duplicates_review/ for your review")
    print("  - Your original folder will not be modified in any way.")


def execute_plan(root, plan):
    out_root = os.path.join(root, "organized")
    by_type_root = os.path.join(out_root, "by-type")
    dup_root = os.path.join(out_root, "duplicates_review")
    os.makedirs(by_type_root, exist_ok=True)
    os.makedirs(dup_root, exist_ok=True)

    for ext, paths in plan["by_type"].items():
        dest_dir = os.path.join(by_type_root, ext.lstrip("."))
        os.makedirs(dest_dir, exist_ok=True)
        for path in paths:
            shutil.copy2(path, os.path.join(dest_dir, os.path.basename(path)))

    for d in plan["duplicates"]:
        shutil.copy2(d["duplicate"], os.path.join(dup_root, os.path.basename(d["duplicate"])))

    print(f"\nDone. Copies written to: {out_root}")
    print("Your original files were not moved, renamed, or deleted.")


def main():
    if len(sys.argv) < 2:
        print("Usage: python organize_files.py /path/to/folder [--execute]")
        sys.exit(1)

    root = sys.argv[1]
    execute = "--execute" in sys.argv

    if not os.path.isdir(root):
        print(f"'{root}' is not a valid folder.")
        sys.exit(1)

    files = scan_folder(root)
    plan = build_plan(root, files)
    print_plan(plan)

    if execute:
        confirm = input("\nType YES to proceed with copying files as planned above: ")
        if confirm.strip() == "YES":
            execute_plan(root, plan)
        else:
            print("Cancelled. Nothing was touched.")
    else:
        print("\nThis was a DRY RUN only. Re-run with --execute to actually copy files.")


if __name__ == "__main__":
    main()
