# Project 4 — Organize the Mess (The Files You Forgot)

## Problem
Real folders (Downloads, Documents) accumulate duplicates, forgotten files, and clutter. This
project involves real file operations, so safety comes first: work on a copy, dry-run before
touching anything.

## AI Tool Used
Claude (claude.ai)

## How It Works
`organize_files.py` scans a folder recursively and:
- Finds true duplicates by comparing file content hashes (not just file names).
- Flags files over 50 MB as "large."
- Groups files by extension.

It **never modifies your originals**. By default it only prints a dry-run plan. Only with
`--execute` (and typing `YES` to confirm) does it copy files into a new `organized/` folder.

## How to Run — Follow the Safety Order
1. **Back up the folder yourself first**, before running anything.
2. Dry run (shows the plan, touches nothing):
```
python organize_files.py /path/to/your/folder
```
3. Read the full plan.
4. Only after approving, execute (still just copies, originals untouched):
```
python organize_files.py /path/to/your/folder --execute
```
5. Check `organized/by-type/` and `organized/duplicates_review/` inside your folder.

## Verification
> Replace with your real check, e.g.:
> "I manually knew there were 2 copies of a photo — the script found exactly that duplicate,
> so I trusted the rest of the scan."

## Result
> Replace with your real outcome, e.g.:
> "Found 1.2 GB of duplicate screenshots I could safely delete, done without touching my
> original files."

## Files
- `organize_files.py` — the script
- `prompts.md` — prompts used to build this script

(No sample data folder is included here since this project runs directly on your real folder —
just point it at any folder on your machine to try it.)
