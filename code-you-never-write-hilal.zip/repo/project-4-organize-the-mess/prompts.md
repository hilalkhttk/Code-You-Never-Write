# Prompts Used — Organize the Mess

## Initial Prompt
"Write a Python script to clean up a messy folder: find duplicate files by content (not just
name), flag files over 50MB, and group files by extension. IMPORTANT: never delete, move, or
rename original files — only copy results into a new output folder. Always show a full dry-run
plan first and require me to explicitly approve before anything is copied."

## Follow-up / Improved Prompt
"Add a confirmation step that requires me to type YES before executing, and make dry-run the
default behavior so nothing happens by accident."

## Notes
> Add real follow-up prompts here if you customized thresholds (e.g. large file size) or added
> more file-type rules for your own folder.
