"""
Money Detective
----------------
Finds recurring charges (possible subscriptions) and duplicate/repeated
payments in your transaction history.

HOW TO USE
1. Replace sample_transactions.csv with your own export (same columns:
   date, description, amount).
2. Run:  python money_detective.py your_transactions.csv
3. Compare the "Total spend" the script prints against a total you
   already know is correct (e.g. from your bank app). If they don't
   match, don't trust the rest of the output yet.

PLAIN-ENGLISH LOGIC
- Recurring charges: group transactions by (description, amount). If the
  same description+amount shows up 2+ times, it's flagged as a likely
  subscription or recurring bill.
- Duplicate charges: same description+amount happening within 3 days of
  each other. This usually means you were charged twice for one thing
  by mistake (rather than a normal monthly recurrence).
- Everything is printed AND saved to findings.csv so you have a record.
"""

import csv
import sys
from collections import defaultdict
from datetime import datetime

DATE_FORMAT = "%Y-%m-%d"
DUPLICATE_WINDOW_DAYS = 3


def load_transactions(path):
    transactions = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            transactions.append({
                "date": datetime.strptime(row["date"].strip(), DATE_FORMAT),
                "description": row["description"].strip(),
                "amount": float(row["amount"]),
            })
    return transactions


def find_recurring(transactions):
    groups = defaultdict(list)
    for t in transactions:
        key = (t["description"], t["amount"])
        groups[key].append(t["date"])

    recurring = []
    for (description, amount), dates in groups.items():
        if len(dates) >= 2:
            recurring.append({
                "description": description,
                "amount": amount,
                "count": len(dates),
                "dates": sorted(d.strftime(DATE_FORMAT) for d in dates),
            })
    recurring.sort(key=lambda r: -r["count"])
    return recurring


def find_duplicates(transactions):
    groups = defaultdict(list)
    for t in transactions:
        key = (t["description"], t["amount"])
        groups[key].append(t["date"])

    duplicates = []
    for (description, amount), dates in groups.items():
        dates = sorted(dates)
        for i in range(1, len(dates)):
            gap = (dates[i] - dates[i - 1]).days
            if gap <= DUPLICATE_WINDOW_DAYS:
                duplicates.append({
                    "description": description,
                    "amount": amount,
                    "date_1": dates[i - 1].strftime(DATE_FORMAT),
                    "date_2": dates[i].strftime(DATE_FORMAT),
                    "gap_days": gap,
                })
    return duplicates


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "sample_transactions.csv"
    transactions = load_transactions(path)

    total_spend = sum(t["amount"] for t in transactions)
    print(f"Loaded {len(transactions)} transactions from {path}")
    print(f"Total spend: {total_spend:.2f}")
    print("--> Check this number against a total you already know is correct.\n")

    recurring = find_recurring(transactions)
    print(f"Possible recurring charges / subscriptions ({len(recurring)} found):")
    for r in recurring:
        print(f"  - {r['description']} @ {r['amount']:.2f}  x{r['count']}  ({', '.join(r['dates'])})")

    duplicates = find_duplicates(transactions)
    print(f"\nPossible duplicate charges ({len(duplicates)} found):")
    for d in duplicates:
        print(f"  - {d['description']} @ {d['amount']:.2f}  charged on {d['date_1']} and {d['date_2']} "
              f"({d['gap_days']} day(s) apart)")

    # Save findings to a CSV for record-keeping
    with open("findings.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["type", "description", "amount", "detail"])
        for r in recurring:
            writer.writerow(["recurring", r["description"], r["amount"], f"{r['count']}x: {', '.join(r['dates'])}"])
        for d in duplicates:
            writer.writerow(["duplicate", d["description"], d["amount"], f"{d['date_1']} & {d['date_2']}"])
    print("\nSaved full findings to findings.csv")


if __name__ == "__main__":
    main()
