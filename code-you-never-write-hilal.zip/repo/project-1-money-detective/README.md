# Project 1 — Money Detective

## Problem
Hunt for spending leaks (forgotten subscriptions, duplicate charges) hiding in real transaction
history — something no ready-made budgeting app can do well, because "what counts as a leak"
is personal.

## AI Tool Used
Claude (claude.ai)

## How It Works
`money_detective.py` reads a CSV of transactions (date, description, amount) and:
1. Groups transactions by identical description + amount to flag likely recurring charges/subscriptions.
2. Flags any matching charge that repeats within 3 days as a possible duplicate/accidental charge.
3. Prints a total spend figure and saves all findings to `findings.csv`.

## How to Run
```
python money_detective.py your_transactions.csv
```
Replace `sample_transactions.csv` with your real (or dummy-sanitized) export first.

## Verification
Before trusting any finding, check the printed **Total spend** figure against a total you
already know is correct (e.g. your bank app's monthly total, or a balance you calculated by hand).

> Replace this section with YOUR real verification numbers, e.g.:
> "My bank app shows total spend for April as X. The script reported Y. These matched, so I
> trusted the recurring-charge findings."

## Result
> Replace with your real finding, e.g.:
> "Found a subscription (`Old Subscription App`) still charging me monthly that I forgot to
> cancel — 1,200 x 3 months = 3,600 wasted."

## Files
- `money_detective.py` — the script
- `sample_transactions.csv` — demo/sample data (replace with your own, sanitized if needed)
- `findings.csv` — output generated when the script runs
- `prompts.md` — prompts used to build this script
