# Prompts Used — Money Detective

## Initial Prompt
"Here is my transaction history as a CSV with columns date, description, amount. Write a Python
script that finds recurring charges (possible subscriptions) and duplicate/repeated payments —
same description and amount happening close together in time. Print a total spend figure so I
can verify it against my own records, and save the findings to a CSV."

## Follow-up / Improved Prompt
"Explain the logic of the duplicate-detection and recurring-charge parts in plain English so I
understand exactly what counts as 'recurring' vs 'duplicate'."

## Notes
> Add any real follow-up prompts you used when adapting this to your own data
> (e.g. "my CSV has a different date format, adjust the script").
