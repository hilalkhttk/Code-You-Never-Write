# Prompts Used — What's My Grade, Really

## Initial Prompt
"Here are my scores as a CSV (category, item, score, max_score). My teacher's grading policy
is: Quizzes 15% (drop lowest 1), Assignments 25%, Midterm 20%, Final Exam 40%. Write a script
that calculates my current grade and tells me what score I need on the final to reach 85%
overall."

## Follow-up / Improved Prompt
"Show me the math for one category by hand-calculation style so I can verify it matches your
script's output before I trust the rest."

## Notes
> Add your real follow-up prompts here, especially if your teacher's rules are more complex
> (e.g. "the lowest quiz is only dropped if I have 5+ quizzes" or bonus-point rules).
