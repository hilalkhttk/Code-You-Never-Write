"""
What's My Grade, Really
------------------------
Encodes YOUR teacher's actual grading rules (weights, dropped scores) and
calculates your true current grade, plus the final-exam score you need
to hit a target grade.

HOW TO USE
1. Put your real scores in scores.csv (columns: category, item, score, max_score).
2. Edit the RULES section below to match your teacher's actual policy.
3. Run:  python grade_calculator.py scores.csv

PLAIN-ENGLISH LOGIC
- Each score is converted to a percentage (score / max_score).
- Within a category, the lowest N scores are dropped if the rule says so,
  then the rest are averaged.
- Each category average is multiplied by its weight and summed to get
  the current grade (out of the categories completed so far).
- The Final Exam category is treated separately: since it hasn't happened
  yet, the script works backwards to tell you the score you'd need on it
  to reach your target overall grade.
"""

import csv
import sys
from collections import defaultdict

# ---------------------------------------------------------------------
# EDIT THIS SECTION to match your real teacher's grading policy
# ---------------------------------------------------------------------
RULES = {
    "weights": {          # must sum to 100 across all categories INCLUDING Final
        "Quiz": 15,
        "Assignment": 25,
        "Midterm": 20,
        "Final": 40,
    },
    "drop_lowest": {       # how many lowest scores to drop per category
        "Quiz": 1,
        "Assignment": 0,
        "Midterm": 0,
    },
}
TARGET_GRADE = 85  # the overall percentage you're aiming for
# ---------------------------------------------------------------------


def load_scores(path):
    by_category = defaultdict(list)
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pct = float(row["score"]) / float(row["max_score"]) * 100
            by_category[row["category"]].append({
                "item": row["item"],
                "pct": pct,
            })
    return by_category


def category_average(category, entries, rules):
    drop_n = rules["drop_lowest"].get(category, 0)
    pcts = sorted(e["pct"] for e in entries)
    kept = pcts[drop_n:] if drop_n < len(pcts) else pcts
    return sum(kept) / len(kept) if kept else 0.0


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "sample_scores.csv"
    by_category = load_scores(path)

    print(f"Loaded scores from {path}\n")

    completed_weight = 0
    weighted_sum = 0
    for category, entries in by_category.items():
        avg = category_average(category, entries, RULES)
        weight = RULES["weights"].get(category, 0)
        completed_weight += weight
        weighted_sum += avg * weight / 100
        dropped = RULES["drop_lowest"].get(category, 0)
        note = f" (lowest {dropped} dropped)" if dropped else ""
        print(f"  {category}: {avg:.1f}%{note}  -> contributes {avg * weight / 100:.2f} pts (weight {weight}%)")

    print(f"\nCurrent grade so far (out of {completed_weight}% of the course completed): "
          f"{weighted_sum:.2f} / {completed_weight}")
    current_pct_of_completed = weighted_sum / completed_weight * 100 if completed_weight else 0
    print(f"  --> That's {current_pct_of_completed:.1f}% on the work graded so far.")
    print("  --> Verify this by hand for ONE category before trusting the rest.\n")

    final_weight = RULES["weights"].get("Final", 0)
    if final_weight:
        # points still needed overall to reach target, coming only from Final
        points_needed = TARGET_GRADE - weighted_sum
        needed_final_pct = points_needed / final_weight * 100
        print(f"To reach a target grade of {TARGET_GRADE}%, you need "
              f"{needed_final_pct:.1f}% on the Final Exam (weight {final_weight}%).")
        if needed_final_pct > 100:
            print("  --> Not mathematically possible anymore with the current scores + rules.")
        elif needed_final_pct < 0:
            print("  --> You've already secured this target grade regardless of the final.")


if __name__ == "__main__":
    main()
