# Project 2 — What's My Grade, Really

## Problem
School grade apps don't know your specific teacher's rules (dropped lowest scores, weighted
categories, final-exam-only weighting). This script encodes those exact rules to calculate your
true current grade and the final-exam score needed to hit a target.

## AI Tool Used
Claude (claude.ai)

## How It Works
`grade_calculator.py` reads `scores.csv` (category, item, score, max_score) and a `RULES`
config (weights per category + how many lowest scores to drop per category). It computes each
category average, weights them, sums the current grade, then works backwards to tell you the
Final Exam score needed to hit `TARGET_GRADE`.

## How to Run
1. Edit the `RULES` dictionary at the top of `grade_calculator.py` to match YOUR teacher's real
   policy (weights must sum to 100, including Final).
2. Replace `sample_scores.csv` with your real scores.
3. Run:
```
python grade_calculator.py scores.csv
```

## Verification
> Replace with your real check, e.g.:
> "I calculated my Assignment category average by hand: (18+17+20)/60 = 91.7%. The script
> reported 91.7% — matched, so I trusted the rest."

## Result
> Replace with your real outcome, e.g.:
> "My current grade is X%. I need Y% on the final to hit my target of 85%."

## Files
- `grade_calculator.py` — the script (edit the RULES section for your teacher's policy)
- `sample_scores.csv` — demo/sample data (replace with your own)
- `prompts.md` — prompts used to build this script
