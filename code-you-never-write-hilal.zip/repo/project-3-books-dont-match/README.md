# Project 3 — The Books Don't Match

## Problem
Reconcile a known, hand-counted total (e.g. trip dues) against a messy digital payment record
with inconsistent names and memos — finding exactly who still owes what.

## AI Tool Used
Claude (claude.ai)

## How It Works
`reconcile.py` translates messy raw payer names into canonical people using your own
`NAME_MAP` rules, sums payments per person, and compares against `EXPECTED_PAYERS`. It reports
shortfalls, overpayments/possible duplicates, missing payers, and any unidentified entries that
need a human decision — then compares the digital total to your known hand-counted total.

## How to Run
1. Edit `KNOWN_TOTAL`, `EXPECTED_PAYERS`, and `NAME_MAP` in `reconcile.py` to match your real
   situation.
2. Replace `sample_payments.csv` with your real (sanitized) payment export, unedited.
3. Run:
```
python reconcile.py payments.csv
```

## Verification
> Replace with your real check, e.g.:
> "I know the correct total is X because I counted cash/confirmed with the group. The script's
> digital total was Y — the gap matched what I'd already suspected was missing."

## Result
> Replace with your real outcome, e.g.:
> "Found that 2 people never paid and 1 payment was unidentified — followed up and resolved it."

## Files
- `reconcile.py` — the script (edit KNOWN_TOTAL / EXPECTED_PAYERS / NAME_MAP for your case)
- `sample_payments.csv` — demo/sample data (replace with your own, sanitized)
- `prompts.md` — prompts used to build this script
