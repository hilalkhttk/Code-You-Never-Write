# Prompts Used — The Books Don't Match

## Initial Prompt
"I collected trip money from 8 people and I know the correct total should be 16,000. Here's my
messy digital payment record as a CSV with inconsistent names and memos. Write a script that
lets me map messy names to real people, sums what each person paid, flags shortfalls, and shows
the gap between the digital total and my known correct total."

## Follow-up / Improved Prompt
"Some entries don't match anyone in my expected list. Instead of ignoring them, list them
separately as 'unidentified' so I can follow up on exactly those."

## Notes
> Add real follow-up prompts here as you adapt NAME_MAP / EXPECTED_PAYERS to your actual group.
