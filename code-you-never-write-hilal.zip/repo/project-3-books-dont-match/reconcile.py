"""
The Books Don't Match
-----------------------
Reconciles a known, hand-counted total against a messy digital payment
record with inconsistent names/memos.

HOW TO USE
1. Set KNOWN_TOTAL below to the real total you counted by hand.
2. Set EXPECTED_PAYERS to the real roster of people who owe money and
   how much each owes.
3. Set NAME_MAP to translate messy raw names in your payment export into
   the canonical person's name (your own knowledge of "who is who").
4. Put your real payment export in payments.csv (columns: date,
   payer_raw, amount, memo) — paste it in exactly as received, don't
   clean it up first.
5. Run: python reconcile.py payments.csv

PLAIN-ENGLISH LOGIC
- Every raw name in the payment file is translated to a canonical name
  using NAME_MAP. Anything not in the map is left as-is and flagged as
  "unidentified" so you know exactly which entries need a human decision.
- Payments are grouped by canonical name and summed. If a person's total
  doesn't match what they owe, that's a shortfall (or overpayment/possible
  duplicate, which is also worth checking).
- People in EXPECTED_PAYERS with NO matching payment at all are listed as
  "no payment found."
- Finally, the digital total is compared to your known hand-counted total
  to show the overall gap.
"""

import csv
import sys
from collections import defaultdict

# ---------------------------------------------------------------------
# EDIT THIS SECTION with your real numbers and rules
# ---------------------------------------------------------------------
KNOWN_TOTAL = 16000  # the total you counted/know is correct

EXPECTED_PAYERS = {
    "Ali": 2000, "Sara": 2000, "Bilal": 2000, "Hina": 2000,
    "Zain": 2000, "Hassan": 2000, "Omar": 2000, "Nida": 2000,
}

# Your own knowledge of "this messy name really means this person"
NAME_MAP = {
    "Ali K": "Ali",
    "ali.khan": "Ali",
    "Sara": "Sara",
    "M. Bilal": "Bilal",
    "Hina A.": "Hina",
    "zain": "Zain",
}
# ---------------------------------------------------------------------


def load_payments(path):
    payments = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            payments.append({
                "date": row["date"],
                "payer_raw": row["payer_raw"].strip(),
                "amount": float(row["amount"]),
                "memo": row.get("memo", "").strip(),
            })
    return payments


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "sample_payments.csv"
    payments = load_payments(path)

    by_person = defaultdict(list)
    unidentified = []

    for p in payments:
        canonical = NAME_MAP.get(p["payer_raw"])
        if canonical:
            by_person[canonical].append(p)
        else:
            unidentified.append(p)

    digital_total = sum(p["amount"] for p in payments)

    print(f"Loaded {len(payments)} payment records from {path}")
    print(f"Digital record total: {digital_total:.2f}")
    print(f"Known (hand-counted) total: {KNOWN_TOTAL:.2f}")
    print(f"Gap: {KNOWN_TOTAL - digital_total:.2f}\n")

    print("Per-person reconciliation:")
    for name, expected in EXPECTED_PAYERS.items():
        paid = sum(p["amount"] for p in by_person.get(name, []))
        n_transactions = len(by_person.get(name, []))
        if paid == 0:
            print(f"  - {name}: NO PAYMENT FOUND (expected {expected:.2f})")
        elif paid < expected:
            print(f"  - {name}: paid {paid:.2f} of {expected:.2f}  -> SHORTFALL {expected - paid:.2f}")
        elif paid > expected:
            print(f"  - {name}: paid {paid:.2f}, expected {expected:.2f}  -> OVERPAID / check for duplicate "
                  f"({n_transactions} transaction(s))")
        else:
            print(f"  - {name}: paid in full ({paid:.2f})")

    if unidentified:
        print(f"\nUnidentified entries needing follow-up ({len(unidentified)}):")
        for u in unidentified:
            print(f"  - {u['date']}: '{u['payer_raw']}' paid {u['amount']:.2f} (memo: '{u['memo']}')")
        print("  --> Add these raw names to NAME_MAP once you know who they are, or follow up directly.")


if __name__ == "__main__":
    main()
